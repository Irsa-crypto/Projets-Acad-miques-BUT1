"""Module capturant les requêtes ICMP et TCP entre deux hôtes A et B"""

#!/usr/bin/env python3

from scapy.all import sniff, IP, TCP, ICMP
import json

def tcp_icmp(ipa, ipb, timeout=60, output="capture.json"):
    """Capture et enregistre les paquets ICMP et TCP"""

    def packet_callback(packet):
        """Renvoie sur le terminal le paquet capturé et l'écrit dans le tableau 
        "captured_packets""""

        #Ecrit les paquets TCP
        if TCP in packet:
            packetSrc = packet[IP].src
            packetSport = packet[TCP].sport
            packetDst = packet[IP].dst
            packetDport = packet[TCP].dport
            print(f"TCP {packetSrc}:{packetSport} -> {packetDst}:{packetDport}")
            captured_packets.append({
                "prot": "TCP",
                "src": f"{packet[IP].src}:{packet[TCP].sport}",
                "dst": f"{packet[IP].dst}:{packet[TCP].dport}" 
            })
            return
        #Ecrit les paquets ICMP (ping)
        elif ICMP in packet:
            print(f"ICMP {packet[IP].src} -> {packet[IP].dst}")
            captured_packets.append({
                "prot": "ICMP",
                "src": packet[IP].src,
                "dst": packet[IP].dst
            })
            return

    captured_packets = []
    #Sniffe les paquets et les envoie dans la méthode callback
    sniff(
        filter=f"host {ipa} and host {ipb}",
        prn=packet_callback,
        timeout=timeout, 
        iface="eth0")

    #Ecrit (en fin de script) les paquets dans un fichier JSON
    with open(output, 'w') as f:
        json.dump(captured_packets, f)
