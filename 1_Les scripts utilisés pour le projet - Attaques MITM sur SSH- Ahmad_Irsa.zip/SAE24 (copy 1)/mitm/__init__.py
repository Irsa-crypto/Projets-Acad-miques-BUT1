"""Message de bienvenue précisant la version du paquet"""
#!/usr/bin/env python3
version="1.0.0"
print("Bienvenue dans le paquet MITM version",version)

