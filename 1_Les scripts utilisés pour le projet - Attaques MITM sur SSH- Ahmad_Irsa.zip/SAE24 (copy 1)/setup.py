"""Script d'installation du paquet "mitm", utiliser la commande :
python3 setup.py install --user"""
from setuptools import setup, find_packages

setup(
    name="mitm",
    version="1.0.0", #Version finale
    description="Module réalisant des attaques MitM via ARP Spoofing",
    packages=find_packages(),
)

